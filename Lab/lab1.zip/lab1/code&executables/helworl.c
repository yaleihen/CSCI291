#include<stdio.h> // we source the stdio.h library for I/O abilities
int main(){ // every program has one main function
    printf("Hello World! \n"); // printf to print "Hello World!"
    return 0; // assign an integer "code" to this program that will be outputted by the shell
}